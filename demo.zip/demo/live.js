
/// App setup
let refresh_speed = 200;

///TCP setup
let tcp_host = "";
let tcp_port = "";
let tcp_log = "Welcome to the TCP console!<br>Here you can send manual TCP requests";

//Connect tobackend
let websocket_link = "ws://192.168.43.79:1880/ws/live";
let ws = new WebSocket(websocket_link);
let key = "D774F27D6E4E6DB554E5267C585FE";
console.log('opening websocket', websocket_link);

function refreshWS(){

	if(ws.readyState === 1){
		// Get spss data
		let pay = {
			key: key,
			type: "refresh_data"
		};
		ws.send(JSON.stringify(pay));
		///console.log('ws_sent', pay)
		setTimeout(refreshWS, refresh_speed);
	}else{
		location.reload();
	}
}	

ws.addEventListener('open', function(e){
	log(['opening websocket', websocket_link]);
	refreshWS();
});
		
ws.addEventListener('message', function(e)	{
		
	let wsdata = JSON.parse(e.data);
	///console.log('ws_rec', wsdata);		

		if(wsdata.type === "refresh_data"){
			let car = wsdata.cars[0];
			setRpm(car.data.engine.rpm);
			setSpeed(car.data.body.speed);
			setTemp(car.data.engine.temp);
			setDTCs(car.data.body.dtc_count,car.data.body.dtcs);
			setPids(car.data.pids);
		}
	
});

///TCP

function updateTCP(){
	tcp_host = document.getElementById('tcp_host').value;
	tcp_port = document.getElementById('tcp_port').value;
	let log = "TCP settings updated<br>Target: " + tcp_host + ":" + tcp_port;
	addTCPlogs(log, "", "", "");
	
}

function killTCP(){

	let ws_msg = {
		key: key,
		type: "tcp",
		port: "",
		host: "",
		input: ""
	};
	addTCPtext("Disconnecting TCP...");
	ws.send(JSON.stringify(ws_msg));
}

function sendTCP(){
	if(document.getElementById('tcp_input').value.length > 0){
	let input = document.getElementById('tcp_input').value + "\r";
	let ws_msg = {
		key: key,
		type: "tcp",
		port: tcp_port,
		host: tcp_host,
		input: input
	};
	addTCPlogs(input, "sent to", tcp_host, tcp_port);
	ws.send(JSON.stringify(ws_msg));
	}
	else{
		alert("Please add input to send");
	}
}

function addTCPtext(text){
	let d = new Date();
	let time = d.toTimeString().split(' ')[0];
	tcp_log = tcp_log + "<br><br>---" + time + "<br><br>" + text;
	let log_div = document.getElementById('tcp_logs');
	log_div.innerHTML = tcp_log;
	log_div.scrollTop = log_div.scrollHeight;
}

function addTCPlogs(log, action, host, port){
	let d = new Date();
	let time = d.toTimeString().split(' ')[0];
	let ip = host ? host + ":" + port : "";
	tcp_log = tcp_log + "<br><br>---" + time + " " + action + " " + ip + "<br><br>" + log;
	let log_div = document.getElementById('tcp_logs');
	log_div.innerHTML = tcp_log;
	log_div.scrollTop = log_div.scrollHeight;
}
function toggleTCP(){
	if(document.getElementById('tcp_console').style.display === "block"){
		document.getElementById('tcp_console').style.display = "none";
	}
	else{
		document.getElementById('tcp_console').style.display = "block";
	}
}


function timeAgo(date) {
    let NOW = Date.now();
let times = [["sec", 1], ["min", 60], ["hour", 3600], ["day", 86400], ["week", 604800], ["month", 2592000], ["year", 31536000]];
    var diff = Math.round((NOW - date) / 1000);
    for (var t = 0; t < times.length; t++) {
        if (diff < times[t][1]) {
            if (t === 0) {
                return "Just now";
            } else {
                diff = Math.round(diff / times[t - 1][1]);
                return diff + " " + times[t - 1][0] + (diff == 1?"":"s");
            }
        }
    }
} 

function secAgo(date){
	let NOW = Date.now();
	var diff = Math.round((NOW - date) / 1000);
	return diff;
}

function log(data){

	let ws_msg = {
		key: key,
		type: "new_log",
		new_log: data				
	};
	console.log(data);
	ws.send(JSON.stringify(ws_msg));
}

function getLog(){
	let ws_msg = {
		key: key,
		type: "get_log"				
	};
	log(["getting logs"]);
	ws.send(JSON.stringify(ws_msg));
}

function downloadObjectAsJson(exportObj, exportName){
    var dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportObj));
    var downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href",     dataStr);
    downloadAnchorNode.setAttribute("download", exportName + ".json");
    document.body.appendChild(downloadAnchorNode); // required for firefox
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  }
	
	
let video;
let yolo;
let isDetecting = false;
let objects = [];
console.log("yolo launching");


document.addEventListener('DOMContentLoaded', function() {
    console.log("Page ready, loading ML");
	setup();
}, false);

function setup() {
 
  createCanvas(800, 600).parent('live_cam');
  video = createCapture(VIDEO);

  // Create a YOLO method
  yolo = ml5.YOLO(video, startDetecting);
  
  console.log("yolo startup complete");
  
  // Hide the original video
  video.hide();
  select('#start').mousePressed(() => {
    if (!isDetecting) {
      select('#start').html('Stop');
      isDetecting = !isDetecting;
      detect();
    } else {
      isDetecting = !isDetecting;
      select('#start').html('Start');
    }
  });
}

function draw() {
  image(video, 0, 0, 800, 600);
  if (isDetecting) {
    for (let i = 0; i < objects.length; i++) {
      noStroke();
      fill(0, 255, 0);
      text(objects[i].className, objects[i].x*width, objects[i].y*height - 5);
      noFill();
      strokeWeight(4);
      stroke(0,255, 0);
      rect(objects[i].x*width, objects[i].y*height, objects[i].w*width, objects[i].h*height);
    }
  }
}

function startDetecting() {
  select('#status').html('Model loaded!')
}

function detect() {
  if (isDetecting) {
    yolo.detect(function(err, results){
      objects = results;
      var wsm = {
        type: "yolo_objects",
        msg: objects
      };
      wsm = JSON.stringify(wsm);
      ws.send(wsm);
      detect();
    });
  }
}

function playSound(url) {
    var a = new Audio(url);
    a.play();
    console.log('playing sound', url);
}

var opts = {
  // basic options
renderTo: "#gauge_rpm"
  
};

let pids_info = [["PID\n(hex)","PID\n(Dec)","Data bytes returned","Description","Min value","Max value","Units","Formula[a]"],["00","0","4","PIDs supported [01 - 20]","","","","Bit encoded [A7..D0] == [PID $01..PID $20] See below"],["01","1","4","Monitor status since DTCs cleared. (Includes malfunction indicator lamp (MIL) status and number of DTCs.)","","","","Bit encoded. See below"],["02","2","2","Freeze DTC","","","",""],["03","3","2","Fuel system status","","","","Bit encoded. See below"],["04","4","1","Calculated engine load","0","100","%"," (or )"],["05","5","1","Engine coolant temperature","-40","215","°C",""],["06","6","1","Short term fuel trim—Bank 1","-100 (Reduce Fuel: Too Rich)","99.2 (Add Fuel: Too Lean)","%","(or  )"],["07","7","1","Long term fuel trim—Bank 1"],["08","8","1","Short term fuel trim—Bank 2"],["09","9","1","Long term fuel trim—Bank 2"],["0A","10","1","Fuel pressure (gauge pressure)","0","765","kPa",""],["0B","11","1","Intake manifold absolute pressure","0","255","kPa",""],["0C","12","2","Engine RPM","0","16,383.75","rpm",""],["0D","13","1","Vehicle speed","0","255","km/h",""],["0E","14","1","Timing advance","-64","63.5","° before TDC",""],["0F","15","1","Intake air temperature","-40","215","°C",""],["10","16","2","MAF air flow rate","0","655.35","grams/sec",""],["11","17","1","Throttle position","0","100","%",""],["12","18","1","Commanded secondary air status","","","","Bit encoded. See below"],["13","19","1","Oxygen sensors present (in 2 banks)","","","","[A0..A3] == Bank 1, Sensors 1-4. [A4..A7] == Bank 2..."],["14","20","2","Oxygen Sensor 1\nA: Voltage\nB: Short term fuel trim","0\n-100","1.275\n99.2","volts\n\n%","(if B==$FF, sensor is not used in trim calculation)"],["15","21","2","Oxygen Sensor 2\nA: Voltage\nB: Short term fuel trim"],["16","22","2","Oxygen Sensor 3\nA: Voltage\nB: Short term fuel trim"],["17","23","2","Oxygen Sensor 4\nA: Voltage\nB: Short term fuel trim"],["18","24","2","Oxygen Sensor 5\nA: Voltage\nB: Short term fuel trim"],["19","25","2","Oxygen Sensor 6\nA: Voltage\nB: Short term fuel trim"],["1A","26","2","Oxygen Sensor 7\nA: Voltage\nB: Short term fuel trim"],["1B","27","2","Oxygen Sensor 8\nA: Voltage\nB: Short term fuel trim"],["1C","28","1","OBD standards this vehicle conforms to","1","250","-","enumerated. See below"],["1D","29","1","Oxygen sensors present (in 4 banks)","","","","Similar to PID 13, but [A0..A7] == [B1S1, B1S2, B2S1, B2S2, B3S1, B3S2, B4S1, B4S2]"],["1E","30","1","Auxiliary input status","","","","A0 == Power Take Off (PTO) status (1 == active)\n[A1..A7] not used"],["1F","31","2","Run time since engine start","0","65,535","seconds",""],["20","32","4","PIDs supported [21 - 40]","","","","Bit encoded [A7..D0] == [PID $21..PID $40] See below"],["21","33","2","Distance traveled with malfunction indicator lamp (MIL) on","0","65,535","km",""],["22","34","2","Fuel Rail Pressure (relative to manifold vacuum)","0","5177.265","kPa",""],["23","35","2","Fuel Rail Gauge Pressure (diesel, or gasoline direct injection)","0","655,350","kPa",""],["24","36","4","Oxygen Sensor 1\nAB: Fuel–Air Equivalence Ratio\nCD: Voltage","0\n0","< 2\n< 8","ratio\nV",""],["25","37","4","Oxygen Sensor 2\nAB: Fuel–Air Equivalence Ratio\nCD: Voltage"],["26","38","4","Oxygen Sensor 3\nAB: Fuel–Air Equivalence Ratio\nCD: Voltage"],["27","39","4","Oxygen Sensor 4\nAB: Fuel–Air Equivalence Ratio\nCD: Voltage"],["28","40","4","Oxygen Sensor 5\nAB: Fuel–Air Equivalence Ratio\nCD: Voltage"],["29","41","4","Oxygen Sensor 6\nAB: Fuel–Air Equivalence Ratio\nCD: Voltage"],["2A","42","4","Oxygen Sensor 7\nAB: Fuel–Air Equivalence Ratio\nCD: Voltage"],["2B","43","4","Oxygen Sensor 8\nAB: Fuel–Air Equivalence Ratio\nCD: Voltage"],["2C","44","1","Commanded EGR","0","100","%",""],["2D","45","1","EGR Error","-100","99.2","%",""],["2E","46","1","Commanded evaporative purge","0","100","%",""],["2F","47","1","Fuel Tank Level Input","0","100","%",""],["30","48","1","Warm-ups since codes cleared","0","255","count",""],["31","49","2","Distance traveled since codes cleared","0","65,535","km",""],["32","50","2","Evap. System Vapor Pressure","-8,192","8191.75","Pa","(AB is two's complement signed)[3]"],["33","51","1","Absolute Barometric Pressure","0","255","kPa",""],["34","52","4","Oxygen Sensor 1\nAB: Fuel–Air Equivalence Ratio\nCD: Current","0\n-128","< 2\n<128","ratio\nmA","or "],["35","53","4","Oxygen Sensor 2\nAB: Fuel–Air Equivalence Ratio\nCD: Current"],["36","54","4","Oxygen Sensor 3\nAB: Fuel–Air Equivalence Ratio\nCD: Current"],["37","55","4","Oxygen Sensor 4\nAB: Fuel–Air Equivalence Ratio\nCD: Current"],["38","56","4","Oxygen Sensor 5\nAB: Fuel–Air Equivalence Ratio\nCD: Current"],["39","57","4","Oxygen Sensor 6\nAB: Fuel–Air Equivalence Ratio\nCD: Current"],["3A","58","4","Oxygen Sensor 7\nAB: Fuel–Air Equivalence Ratio\nCD: Current"],["3B","59","4","Oxygen Sensor 8\nAB: Fuel–Air Equivalence Ratio\nCD: Current"],["3C","60","2","Catalyst Temperature: Bank 1, Sensor 1","-40","6,513.5","°C",""],["3D","61","2","Catalyst Temperature: Bank 2, Sensor 1"],["3E","62","2","Catalyst Temperature: Bank 1, Sensor 2"],["3F","63","2","Catalyst Temperature: Bank 2, Sensor 2"],["40","64","4","PIDs supported [41 - 60]","","","","Bit encoded [A7..D0] == [PID $41..PID $60] See below"],["41","65","4","Monitor status this drive cycle","","","","Bit encoded. See below"],["42","66","2","Control module voltage","0","65.535","V",""],["43","67","2","Absolute load value","0","25,700","%",""],["44","68","2","Fuel–Air commanded equivalence ratio","0","< 2","ratio",""],["45","69","1","Relative throttle position","0","100","%",""],["46","70","1","Ambient air temperature","-40","215","°C",""],["47","71","1","Absolute throttle position B","0","100","%",""],["48","72","1","Absolute throttle position C"],["49","73","1","Accelerator pedal position D"],["4A","74","1","Accelerator pedal position E"],["4B","75","1","Accelerator pedal position F"],["4C","76","1","Commanded throttle actuator"],["4D","77","2","Time run with MIL on","0","65,535","minutes",""],["4E","78","2","Time since trouble codes cleared"],["4F","79","4","Maximum value for Fuel–Air equivalence ratio, oxygen sensor voltage, oxygen sensor current, and intake manifold absolute pressure","0, 0, 0, 0","255, 255, 255, 2550","ratio, V, mA, kPa","A, B, C, D*10"],["50","80","4","Maximum value for air flow rate from mass air flow sensor","0","2550","g/s","A*10, B, C, and D are reserved for future use"],["51","81","1","Fuel Type","","","","From fuel type table see below"],["52","82","1","Ethanol fuel %","0","100","%",""],["53","83","2","Absolute Evap system Vapor Pressure","0","327.675","kPa",""],["54","84","2","Evap system vapor pressure","-32,767","32,768","Pa","((A*256)+B)-32767"],["55","85","2","Short term secondary oxygen sensor trim, A: bank 1, B: bank 3","-100","99.2","%",""],["56","86","2","Long term secondary oxygen sensor trim, A: bank 1, B: bank 3"],["57","87","2","Short term secondary oxygen sensor trim, A: bank 2, B: bank 4"],["58","88","2","Long term secondary oxygen sensor trim, A: bank 2, B: bank 4"],["59","89","2","Fuel rail absolute pressure","0","655,350","kPa",""],["5A","90","1","Relative accelerator pedal position","0","100","%",""],["5B","91","1","Hybrid battery pack remaining life","0","100","%",""],["5C","92","1","Engine oil temperature","-40","210","°C",""],["5D","93","2","Fuel injection timing","-210.00","301.992","°",""],["5E","94","2","Engine fuel rate","0","3212.75","L/h",""],["5F","95","1","Emission requirements to which vehicle is designed","","","","Bit Encoded"],["60","96","4","PIDs supported [61 - 80]","","","","Bit encoded [A7..D0] == [PID $61..PID $80] See below"],["61","97","1","Driver's demand engine - percent torque","-125","130","%","A-125"],["62","98","1","Actual engine - percent torque","-125","130","%","A-125"],["63","99","2","Engine reference torque","0","65,535","Nm",""],["64","100","5","Engine percent torque data","-125","130","%","A-125 Idle\nB-125 Engine point 1\nC-125 Engine point 2\nD-125 Engine point 3\nE-125 Engine point 4"],["65","101","2","Auxiliary input / output supported","","","","Bit Encoded"],["66","102","5","Mass air flow sensor","","","",""],["67","103","3","Engine coolant temperature","","","°C",""],["68","104","7","Intake air temperature sensor","","","",""],["69","105","7","Commanded EGR and EGR Error","","","",""],["6A","106","5","Commanded Diesel intake air flow control and relative intake air flow position","","","",""],["6B","107","5","Exhaust gas recirculation temperature","","","",""],["6C","108","5","Commanded throttle actuator control and relative throttle position","","","",""],["6D","109","6","Fuel pressure control system","","","",""],["6E","110","5","Injection pressure control system","","","",""],["6F","111","3","Turbocharger compressor inlet pressure","","","",""],["70","112","9","Boost pressure control","","","",""],["71","113","5","Variable Geometry turbo (VGT) control","","","",""],["72","114","5","Wastegate control","","","",""],["73","115","5","Exhaust pressure","","","",""],["74","116","5","Turbocharger RPM","","","",""],["75","117","7","Turbocharger temperature","","","",""],["76","118","7","Turbocharger temperature","","","",""],["77","119","5","Charge air cooler temperature (CACT)","","","",""],["78","120","9","Exhaust Gas temperature (EGT) Bank 1","","","","Special PID. See below"],["79","121","9","Exhaust Gas temperature (EGT) Bank 2","","","","Special PID. See below"],["7A","122","7","Diesel particulate filter (DPF)","","","",""],["7B","123","7","Diesel particulate filter (DPF)","","","",""],["7C","124","9","Diesel Particulate filter (DPF) temperature","","","°C",""],["7D","125","1","NOx NTE (Not-To-Exceed) control area status","","","",""],["7E","126","1","PM NTE (Not-To-Exceed) control area status","","","",""],["7F","127","13","Engine run time","","","seconds",""],["80","128","4","PIDs supported [81 - A0]","","","","Bit encoded [A7..D0] == [PID $81..PID $A0] See below"],["81","129","21","Engine run time for Auxiliary Emissions Control Device(AECD)","","","",""],["82","130","21","Engine run time for Auxiliary Emissions Control Device(AECD)","","","",""],["83","131","5","NOx sensor","","","",""],["84","132","1","Manifold surface temperature","","","",""],["85","133","10","NOx reagent system","","","",""],["86","134","5","Particulate matter (PM) sensor","","","",""],["87","135","5","Intake manifold absolute pressure","","","",""],["88","136","13","SCR Induce System","","","",""],["89","137","41","Run Time for AECD #11-#15","","","",""],["8A","138","41","Run Time for AECD #16-#20","","","",""],["8B","139","7","Diesel Aftertreatment","","","",""],["8C","140","16","O2 Sensor (Wide Range)","","","",""],["8D","141","1","Throttle Position G","0","100","%",""],["8E","142","1","Engine Friction - Percent Torque","-125","130","%",""],["8F","143","5","PM Sensor Bank 1 & 2","","","",""],["90","144","3","WWH-OBD Vehicle OBD System Information","","","hours",""],["91","145","5","WWH-OBD Vehicle OBD System Information","","","hours",""],["92","146","2","Fuel System Control","","","",""],["93","147","3","WWH-OBD Vehicle OBD Counters support","","","hours",""],["94","148","12","NOx Warning And Inducement System","","","",""],["98","152","9","Exhaust Gas Temperature Sensor","","","",""],["99","153","9","Exhaust Gas Temperature Sensor","","","",""],["9A","154","6","Hybrid/EV Vehicle System Data, Battery, Voltage","","","",""],["9B","155","4","Diesel Exhaust Fluid Sensor Data","","","",""],["9C","156","17","O2 Sensor Data","","","",""],["9D","157","4","Engine Fuel Rate","","","g/s",""],["9E","158","2","Engine Exhaust Flow Rate","","","kg/h",""],["9F","159","9","Fuel System Percentage Use","","","",""],["A0","160","4","PIDs supported [A1 - C0]","","","","Bit encoded [A7..D0] == [PID $A1..PID $C0] See below"],["A1","161","9","NOx Sensor Corrected Data","","","ppm",""],["A2","162","2","Cylinder Fuel Rate","","","mg/stroke",""],["A3","163","9","Evap System Vapor Pressure","","","Pa",""],["A4","164","4","Transmission Actual Gear","","","",""],["A5","165","4","Diesel Exhaust Fluid Dosing","","","",""],["A6","166","4","Odometer","0","526 385 151.9","km","km/8, about hm"],["C0","192","4","PIDs supported [C1 - E0]","0x0","0xffffffff","","Bit encoded [A7..D0] == [PID $C1..PID $E0] See below"],["C3","195","?","?","?","?","?","Returns numerous data, including Drive Condition ID and Engine Speed*"],["C4","196","?","?","?","?","?","B5 is Engine Idle Request\nB6 is Engine Stop Request*"]];

let gauges = document.gauges;

function setSpeed(value){
gauges[0].value = value; // set actual value
}

function setRpm(value){
gauges[1].value = value; // set actual value
}

function setTemp(value){
gauges[2].value = value; // set actual value
}

function setDTCs(count,dtcs){
	let info = count + " DTCs found in this car<br>";
	
	let table = "";
		for(i=0; i<dtcs.length; i++){
			if(dtcs[i].length > 2){
				let dtc = dtcs[i];
				let generic = dtc.substring(1,2);
				let url = "https://www.obd-codes.com/";
					if(generic === "0"){
						url = url + dtc;
					}else{
						url = url + "trouble_codes/"
					}
				let link = "<a target=_blank href=" + url + ">" + dtc + "</a>";
				let nr = i+1;
				table = table + nr + ") " + link + "<br>";
			}
		}

	document.getElementById("dtcs_info").innerHTML = info + table;
}

function setPids(pids){
	let table = "";
	
	for(i=0; i<pids.length; i++){
    if(pids[i] === true || pids[i] === false){
        let pid = pids[i];
        if(pid === true){
        let pinfo = pids_info[i+1];
        table = table + i + ") " + pinfo[0] + " - " + pinfo[3] + "<br>";
        }
    }
	}


	document.getElementById("pids_info").innerHTML = table;
}

function toggleMenu(){
	let menu = document.getElementById("live_menu");
	
	if(menu.style.display === "block"){
		menu.style.display = "none";
	}else{
		menu.style.display = "block";
	}
}

function toggleInfo(){
	let menu = document.getElementById("info_screen");
	
	if(menu.style.display === "block"){
		menu.style.display = "none";
	}else{
		menu.style.display = "block";
	}
}